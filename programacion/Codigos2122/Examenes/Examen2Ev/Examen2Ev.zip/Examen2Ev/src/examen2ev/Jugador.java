package examen2ev;

public final class Jugador extends Persona{

    String posicion;
    int sueldo;

    public Jugador() {
    }

    public Jugador(String nombre, String apellido, String dni, int edad, String posicion, int sueldo) {
        super(nombre, apellido, dni, edad);
        this.posicion = posicion;
        this.sueldo = sueldo;
        calcularSueldo();
    }
    //metodos

    @Override
    public void mostrarDatos() {
        super.mostrarDatos();
    }

    @Override
    public void calcularSueldo() {
        super.calcularSueldo();
        this.sueldo = this.sueldo + (int) (this.sueldo *0.5);
    }
    //getter y setter

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }
}
