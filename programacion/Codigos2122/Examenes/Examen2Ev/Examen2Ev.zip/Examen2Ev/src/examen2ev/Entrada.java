package examen2ev;

public class Entrada {
    public static void main(String[] args) {

        Seleccion seleccion = new Seleccion("España");

        Jugador jugador1 = new Jugador("sergio","santurde","1243124r",21,"delantero",4000);
        seleccion.contratarJugador(jugador1);
        Jugador jugador2 = new Jugador("lucas","ruiz","21432e",27,"defensa",2000);
        seleccion.contratarJugador(jugador2);
        Jugador jugador3 = new Jugador("Pedro","Zarapico","41234r",24,"medio",3000);
        seleccion.contratarJugador(jugador3);
        Jugador jugador4 = new Jugador("Francisco","Trueva","214125t",31,"portero",2500);
        seleccion.contratarJugador(jugador4);

        Entrenador entrenador1 = new Entrenador("david","trujillo","321341r",47,"defensiva",5000);
        seleccion.contratarEntrenador(entrenador1);
        Entrenador entrenador2 = new Entrenador("Luis","Gallardo","'18752135n",32,"ofensiva",5000);
        seleccion.contratarEntrenador(entrenador2);
        


    }
}
