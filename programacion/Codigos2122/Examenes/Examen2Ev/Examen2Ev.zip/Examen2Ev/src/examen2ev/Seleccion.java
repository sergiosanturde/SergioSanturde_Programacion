package examen2ev;

import java.util.ArrayList;

public final class Seleccion {

    String nombre;
    int gastos;
    private double costeTotal = 0;

    ArrayList<Persona> listaPersonas;

    public Seleccion(ArrayList<Persona> listaPersonas) {
        this.listaPersonas = listaPersonas;
    }
    public Seleccion(String nombre) {
        this.nombre = nombre;
    }

    //metodos
    public void contratarJugador(Jugador jugador){
        for (int i = 0; i < listaPersonas.size(); i++) {
            if (listaPersonas.get(i).getDni().equalsIgnoreCase(jugador.getDni())){
                System.out.println("Jugador Contratado");
            }
        }
    }
    public void contratarEntrenador(Entrenador entrenador) {
        for (int i = 0; i < listaPersonas.size(); i++) {
            if (listaPersonas.get(i).getDni().equalsIgnoreCase(entrenador.getDni())) {
                System.out.println("Entrenador Contratado");
            }
        }
    }


    public void verPosicion(){
            for (Persona item : listaPersonas ) {
                if (item instanceof Jugador){
                    ((Jugador) item).getPosicion();
                }
            }
    }

    public void verJugadores(){
        for ( Persona item : listaPersonas ) {
            if (item instanceof Jugador){
                item.mostrarDatos();
            }
        }
    }

    public void verEntrenadores(){
        for ( Persona item : listaPersonas ) {
            if (item instanceof Entrenador){
                item.mostrarDatos();
            }
        }
    }
    public void verPlantilla(){
        for ( Persona item: listaPersonas) {
            System.out.println(item.getClass().getSimpleName());
            item.mostrarDatos();
        }
    }
    public void mostarGastos(){
        for ( Persona item : listaPersonas) {
            costeTotal += item.sueldo;
        }
        System.out.println("El coste es: "+ costeTotal);
    }
}

