package reestaurante;

public enum TipoBebidas {

    Copas,Cervezas,Refrescos
}
