package reestaurante;

public class ExcepcionPersonalizada extends Exception{

    public ExcepcionPersonalizada(String message){
        super(message);
    }
}
