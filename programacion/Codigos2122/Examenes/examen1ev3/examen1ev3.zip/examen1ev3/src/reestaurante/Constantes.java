package reestaurante;

public interface Constantes {

    double IVA_BEBIDASBARRA = 0.21;
    double IVA_BEBIDASRESTAURANTE = 0.10;
    String CIF = "123123123A";
}
