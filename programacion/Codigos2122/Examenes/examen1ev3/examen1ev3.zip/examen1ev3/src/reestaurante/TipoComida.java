package reestaurante;

public enum TipoComida {

    Menu,Raciones,Bocadillo;
}
