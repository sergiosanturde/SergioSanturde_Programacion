import controller.Controller1;


public class MainEjer1 {
    public static void main(String[] args) {

        Controller1 controller = new Controller1();
        controller.cifrarTexto();

    }
}
