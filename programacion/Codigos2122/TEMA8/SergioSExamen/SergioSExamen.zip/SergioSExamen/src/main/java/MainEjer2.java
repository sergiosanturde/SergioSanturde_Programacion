import controller.Controller2;

public class MainEjer2 {

    public static void main(String[] args) {
        Controller2 controller = new Controller2();
        controller.leerUsuarios();
    }
}
