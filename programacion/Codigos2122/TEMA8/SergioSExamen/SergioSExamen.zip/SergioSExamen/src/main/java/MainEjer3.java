import controller.Controller3;

public class MainEjer3 {
    public static void main(String[] args) {




        Controller3 controller = new Controller3();
        controller.
    }
}
